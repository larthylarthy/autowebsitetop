# Credits
## SVG icons
* Eva Icons - MIT License - https://github.com/akveo/eva-icons
* IonIcons - MIT license - https://ionic.io/ionicons
* Freebiesbug - CC BY - https://freebiesbug.com/psd-freebies/150-free-outlined-icons-psd-ai-svg-webfont/
* Line Awesome - MIT license - https://icons8.com/line-awesome
* 77 Essential Icons - CC BY 4.0 - https://dribbble.com/shots/1934932-77-Essential-Icons-Free-Download
* Dripicons - CC BY 4.0 - https://github.com/amitjakhu/dripicons
* Themify Icons - MIT License - https://themify.me/themify-icons
* Feather - MIT License - https://github.com/feathericons/feather
* Boxicons  - MIT License - https://boxicons.com/
* Linea - CC BY 4.0 - https://www.linea.is/
* Core UI - CC BY 4.0 - https://github.com/coreui/coreui-icons
* Open Iconic - MIT License - https://useiconic.com/open/
* Font Awesome - CC BY 4.0 https://github.com/FortAwesome/Font-Awesome
* Elegant Icon Font - MIT License - https://www.elegantthemes.com/blog/resources/elegant-icon-font
* Material Design - Apache 2.0 - https://github.com/Templarian/MaterialDesign
* RemixIcon - Apache 2.0 License -https://github.com/Iconscout/unicons
* Unicons - Apache 2.0 License -https://github.com/Remix-Design/remixicon
* clarity-icons - MIT License - https://clarity.design/foundation/icons/
* Jam icons - MIT License - https://v2.jam-icons.com/
* Ant Design SVG icons - MIT License - https://github.com/ant-design/ant-design-icons
* Olicons - CC BY - https://github.com/owlling/olicons
* Css.gg - MIT License -https://github.com/astrit/css.gg
* Tabler icons - MIT License - https://github.com/tabler/tabler-icons
* Ikonate - MIT License - https://github.com/mikolajdobrucki/ikonate
* iconoir - MIT License - https://github.com/lucaburgio/iconoir
* octicons - MIT License - https://github.com/primer/octicons
* heroicons - MIT License - https://github.com/tailwindlabs/heroicons
* Health Icons - MIT License - https://github.com/resolvetosavelives/healthicons
* iconsax - Custom Free License - https://github.com/lusaxweb/iconsax
* System-uicons - Unilicense - https://github.com/CoreyGinnivan/system-uicons

